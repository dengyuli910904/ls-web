<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Index_news_categoridModel extends Model
{
    protected $table = 'index_news_categorid';
    public $timestamp = true;
}
