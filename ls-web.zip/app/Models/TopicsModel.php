<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TopicsModel extends Model
{
    protected $table = 'topics';
    public $timestamp = true;
}
