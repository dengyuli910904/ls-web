<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TopicsNewsModel extends Model
{
    protected $table = 'topics_news';
    public $timestamp = true;
}
