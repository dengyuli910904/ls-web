<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SponsorModel extends Model
{
    protected $table = 'sponsors';
    public $timestamp = true;
}
