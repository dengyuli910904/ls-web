<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NewsModel extends Model
{
    protected $table = 'news';
    public $timestamp = true;
    protected $casts = [
	    'id' => 'string'
	];
}
