<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class FriendshipModel extends Model
{
    protected $table = 'friendships';
    public $timestamp = true;
}
