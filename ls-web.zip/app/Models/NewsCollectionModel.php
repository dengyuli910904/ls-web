<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class NewsCollectionModel extends Model
{
   	protected $table = 'news_collection';
   	public $timestamp = true;
}
