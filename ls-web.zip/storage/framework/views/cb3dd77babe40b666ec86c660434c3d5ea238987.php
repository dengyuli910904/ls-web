;
<?php $__env->startSection('title','新闻类型管理'); ?>
<?php $__env->startSection('banner-title','新闻类型管理'); ?>
<?php $__env->startSection('banner-tips','新闻类型添加'); ?>

<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('left-menu'); ?>
     ##parent-placeholder-079b8c54e4ea0ef26a7473045f2099d46b079c86##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<div class="panel panel-default">
    <div class="panel-heading">
        <h2><i class="fa fa-indent red"></i><strong>添加新闻类型</strong></h2>
    </div>
    <div class="col-lg-12">
       <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
          <strong>提示!</strong> 您的操作失败<br><br>
          <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>
    </div>
    <form action="<?php echo e(url('newstype/doadd')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal ">
        <div class="panel-body">
            <div class="form-group">
                <label class="col-md-3 control-label" for="text-input">类型名称</label>
                <div class="col-md-9">
                    <input type="text" id="name" name="name" class="form-control" placeholder="请输入新闻标题......">
                    <!-- <span class="help-block">This is a help text</span> -->
                </div>
            </div>
            
            <div class="form-group">
                <label class="col-md-3 control-label">描述</label>
                <div class="col-md-9">
                    <input type="text" id="description" name="description" class="form-control" placeholder="请输入新闻类型描述......">
                </div>
            </div>
        </div>
        <div class="panel-footer">
            <button type="submit" class="btn btn-sm btn-success"><i class="fa fa-dot-circle-o"></i> 提交</button>
            <!-- <button type="reset" class="btn btn-sm btn-danger"><i class="fa fa-ban"></i> 重置</button> -->
        </div> 
    </form> 
   
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>