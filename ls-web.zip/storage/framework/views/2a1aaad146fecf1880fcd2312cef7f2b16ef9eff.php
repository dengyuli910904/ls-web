<footer class="footer-theme">
        <div class="container">
            <div class="row">
                <img src="<?php echo e(asset('images/logo.jpg')); ?>"  height="60px">
                <!-- <img src="<?php echo e(asset('images/erweima.png')); ?>" height="100px">  -->
            </div>
            <div class="row">
                <h3>海南体育赛事频道</h3>
            </div>
            <div class="row pd-t-10">
                <!-- <div class="col-md-2"></div> -->
                <div class="col-md-3  col-xs-6 col-lg-3 t-l">
                    <p class=" b-r">地址：深圳市南山区深南大道</p>
                </div>
                <div class="col-md-3  col-xs-6 col-lg-3 t-l">
                    <p class=" b-r">邮箱：lily@livesong.cn</p>
                </div>
                <div class="col-md-3  col-xs-6 col-lg-3 t-l">
                    <p class=" b-r">热线：86-0755-1234656</p>
                </div>
                <div class="col-md-3  col-xs-6 col-lg-3 t-l">
                    <p>传真：86-0755-1234656</p>
                </div>
                <!-- <div class="col-md-2"></div> -->
            </div>
             <div class="row pd-t-10">
                @2017-2018 海南体育 版权所有 关于海南体育 | 联系我们 | 合作模式 | 海ICP备00000000号-1
            </div>
        </div>
    </footer>