<?php $__env->startSection('title','banner管理'); ?>
<?php $__env->startSection('banner-title','banner管理'); ?>
<?php $__env->startSection('banner-tips','banner列表'); ?>

<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('left-menu'); ?>
     ##parent-placeholder-079b8c54e4ea0ef26a7473045f2099d46b079c86##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
            
            
            <div class="row">  
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h2><i class="fa fa-table red"></i><span class="break"></span><strong>banner管理</strong></h2>
                              <div class="panel-actions">
                                <!-- <a href="table.html#" class="btn-setting"><i class="fa fa-rotate-right"></i></a>
                                <a href="table.html#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a> -->
                                <!-- <a href="<?php echo e(url('banner/add')); ?>"><i class="fa fa-times"></i></a> -->
                                
                              </div> 


                        </div>
                        <div class="col-lg-12">
                           <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                              <strong>提示!</strong> 您的操作失败<br><br>
                              <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                            </div>
                          <?php endif; ?>
                        </div>
                        <div class="panel-body">
                            <form action="<?php echo e(url('admin/news/list')); ?>" method="POST">
                              <div class="row">
                                <div class="col-md-3">
                                  <input type="text" id="searchtxt" name="searchtxt" class="form-control" placeholder="请输入新闻标题......">
                                </div>
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-primary" onclick="window.location.href='<?php echo e(url('adminh/news/list')); ?>'">搜索</button>
                                    <button type="button" class="btn btn-default" onclick="window.location.href='<?php echo e(url('admin/news/add')); ?>'">添加</button>
                                </div>
                              </div>
                            </form>
                            <table class="table table-bordered table-striped table-condensed table-hover">
                                  <thead>
                                      <tr>
                                         <th width="20%">标题</th>
                                         <th width="20%">简介</th>
                                         <th width="7%">类型</th>
                                         <th width="10%">标签</th>
                                         <th width="10%">关键词</th>
                                         <th width="10%">来源</th>
                                         <th width="8%">是否显示</th>
                                         <th width="15%">操作</th>                                          
                                      </tr>
                                  </thead>   
                                  <tbody>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($val->title); ?></td>
                                        <td><?php echo e($val->intro); ?></td>
                                        <td>1</td>
                                        <td><?php echo e($val->tags); ?></td>
                                        <td><?php echo e($val->keyword); ?></td>
                                        <td><?php echo e($val->resource); ?></td>
                                        <td><?php echo e($val->is_hidden === 1?'启用':'禁用'); ?></td>
                                        <td>
                                            <form action="" method="post" style="display: inline;"> 
                                              <input type="hidden" name="id" value="<?php echo e($val->id); ?>"> 
                                              <input type="hidden" name="isfalse" value="<?php echo e($val->is_hidden); ?>">
                                              <?php if($val->is_hidden): ?>
                                              <button type="submit" class="btn btn-default">禁用</button>
                                              <?php else: ?>
                                              <button type="submit" class="btn btn-success">启用</button>
                                              <?php endif; ?>
                                            </form>
                                            <button type="button" class="btn btn-primary" onclick="window.location.href='<?php echo e(url('admin/news/edit?uuid='.$val->id)); ?>'">编辑</button>
                                            <button type="button" class="btn btn-danger" onclick="window.location.href='<?php echo e(url('admin/news/delete?uuid='.$val->id)); ?>'">删除</button>
                                        </td>                                       
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                    
                                  </tbody>
                             </table>
                             <?php echo e($data->links()); ?> 
                             <!-- <ul class="pagination">
                                <li><a href="table.html#">上一页</a></li>
                                <li class="active">
                                  <a href="table.html#">1</a>
                                </li>
                                <li><a href="table.html#">2</a></li>
                                <li><a href="table.html#">3</a></li>
                                <li><a href="table.html#">4</a></li>
                                <li><a href="table.html#">5</a></li>
                                <li><a href="table.html#">下一页</a></li>
                              </ul>      -->
                        </div>
                    </div>
                </div><!--/col-->
            </div>    
                    
        </div>
      <script type="text/javascript">
          // $.ajax({
          //   url: "<?php echo e(url('banner/handle')); ?>",
          //   type:'Post',
          //   data:{
          //     id:1,
          //     isfalse:0
          //   },
          //   success: function(data){
          //       alert('dfdfd');
          //   }
          // });
      </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>