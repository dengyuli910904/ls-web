<?php $__env->startSection('title','专题管理'); ?>
<?php $__env->startSection('banner-title','专题管理'); ?>
<?php $__env->startSection('banner-tips','专题列表'); ?>

<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('left-menu'); ?>
     ##parent-placeholder-079b8c54e4ea0ef26a7473045f2099d46b079c86##
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
            
            
            <div class="row">  
                <div class="col-lg-12">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            <h2><i class="fa fa-table red"></i><span class="break"></span><strong>专题管理</strong></h2>
                              <div class="panel-actions">
                                <!-- <a href="table.html#" class="btn-setting"><i class="fa fa-rotate-right"></i></a>
                                <a href="table.html#" class="btn-minimize"><i class="fa fa-chevron-up"></i></a> -->
                                <!-- <a href="<?php echo e(url('banner/add')); ?>"><i class="fa fa-times"></i></a> -->
                                
                              </div> 


                        </div>
                        <div class="col-lg-12">
                           <?php if(count($errors) > 0): ?>
                            <div class="alert alert-danger">
                              <strong>提示!</strong> 您的操作失败<br><br>
                              <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                            </div>
                          <?php endif; ?>
                        </div>
                        <div class="panel-body">
                            <form action="<?php echo e(route('topics.index')); ?>" method="get">
                              <div class="row">
                                <div class="col-md-3">
                                  <input type="text" id="searchtxt" name="name" class="form-control" placeholder="请输入专题标题......">
                                </div>
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-primary">搜索</button>
                                    <button type="button" class="btn btn-default" onclick="window.location.href='<?php echo e(route('topics.create')); ?>'">添加</button>
                                </div>
                              </div>
                            </form>
                            <table class="table table-bordered table-striped table-condensed table-hover">
                                  <thead>
                                      <tr>
                                         <th width="20%">标题</th>
                                         <th width="20%">简介</th>
                                         <th width="8%">是否显示</th>
                                         <th width="15%">操作</th>                                          
                                      </tr>
                                  </thead>   
                                  <tbody>
                                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($val->title); ?></td>
                                        <td><?php echo e($val->intro); ?></td>
                                        <td><?php echo e($val->is_hidden === 0?'启用':'禁用'); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-default" onclick="window.location.href='<?php echo e(route('topics-news.index', ['topics_id' => $val->id])); ?>'">专题新闻</button>
                                            <button type="button" class="btn btn-primary" onclick="window.location.href='<?php echo e(route('topics.edit', ['id' => $val->id])); ?>'">编辑</button>
                                            <button type="button" class="btn btn-danger" onclick="del('<?php echo e($val->id); ?>')">删除</button>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                                    
                                  </tbody>
                             </table>
                             <?php echo e($list->links()); ?>

                             <!-- <ul class="pagination">
                                <li><a href="table.html#">上一页</a></li>
                                <li class="active">
                                  <a href="table.html#">1</a>
                                </li>
                                <li><a href="table.html#">2</a></li>
                                <li><a href="table.html#">3</a></li>
                                <li><a href="table.html#">4</a></li>
                                <li><a href="table.html#">5</a></li>
                                <li><a href="table.html#">下一页</a></li>
                              </ul>      -->
                        </div>
                    </div>
                </div><!--/col-->
            </div>    
                    
        </div>
      <script type="text/javascript">
          function del(id)
          {
              $.ajax({
                  url: "/admin/topics/" + id,
                  type:'post',
                  data:{
                       _method: 'delete'
                  },
                  dataType: 'json',
                  success: function(data){
                      alert(data.msg);
                      window.location.reload();
                  }
              });
          }
      </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>