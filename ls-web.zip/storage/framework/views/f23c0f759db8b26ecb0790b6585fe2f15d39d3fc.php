  <!-- Scripts -->
<!--<script src="<?php echo e(asset('js/app.js')); ?>"></script>-->
<!-- jQuery -->

    <?php $__env->startSection('javascript'); ?>

    <!-- Scripts -->
    <!--<script src="<?php echo e(asset('js/app.js')); ?>"></script>-->
    <!-- jQuery -->
    

    <!-- Plugin JavaScript -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js" integrity="sha384-mE6eXfrb8jxl0rzJDBRanYqgBxtJ6Unn4/1F7q4xRRyIw7Vdg9jP4ycT7x1iVsgb" crossorigin="anonymous"></script>

    <!-- Contact Form JavaScript -->
    <script src="<?php echo e(asset('web/js/jqBootstrapValidation.js')); ?>"></script>
    <script src="<?php echo e(asset('web/js/contact_me.js')); ?>"></script>

    <!-- Theme JavaScript -->

    <!--<script src="<?php echo e(asset('web/js/agency.js')); ?>"></script>-->

    <?php echo $__env->yieldSection(); ?>