<?php $__env->startSection('style'); ?>
    ##parent-placeholder-26ec8d00fb6b55466b3a115f1d559422a7fa7aac##
    <link href="<?php echo e(asset('css/topics.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="pd-t-20 pd-b-20">
        <div class="container">
            <div class="row">
                <div class="col-md-12 pd-b-20">
                    <h4><span>专题列表</span> | <span>LIST OF TOPICS</span></h4>
                </div>
            </div>
            <div class="col-md-12">
                <div class="newslist">
                    <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="new-item col-md-6 row">
                            <a href="/topics/<?php echo e($l->id); ?>">
                                <div class="pd-b-10"><img src="<?php echo e($l->cover); ?>"></div>
                                <h4 class=" text-center"><?php echo e($l->title); ?></h4>
                                <h5 class=" text-center"><?php echo e($l->created_at); ?></h5>
                            </a>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="topics-bottom text-center col-md-12">
                <div class="col-md-4 topics-bottom-left">　</div>
                <div class="col-md-4 topics-bottom-center">下拉加载更多</div>
                <div class="col-md-4 topics-bottom-right">　</div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    ##parent-placeholder-b6e13ad53d8ec41b034c49f131c64e99cf25207a##
    <script src="<?php echo e(asset('web/js/topics.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>