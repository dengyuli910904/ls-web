<script src="<?php echo asset('/laravel-u-editor/ueditor.config.js'); ?>"></script>
<script src="<?php echo asset('/laravel-u-editor/ueditor.all.min.js'); ?>"></script>

<script src="<?php echo asset($UeditorLangFile); ?>"></script>