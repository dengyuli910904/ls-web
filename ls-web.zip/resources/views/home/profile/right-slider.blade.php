<div class="row">
    <div class="col-md-12  pd-b-30 pd-l-40">
        <h4><a href="#"><span>热门专题</span> | <span>HOT TOPIC</span></a></h4>
    </div>
</div>
<div id="hottopic">
    <ul>
        <li><a href="#">2016年体坛总结</a></li>
        <li><a href="#">2017年黄金海岸马拉松</a></li>
        <li><a href="#">越山向海</a></li>
        <li><a href="#">联合会杯彩票专栏</a></li>
        <li><a href="#">卡拉宝花式足球世界杯</a></li>
        <li><a href="#">2017年联合会杯</a></li>
        <li><a href="#">2017高尔夫美国公开赛</a></li>
        <li><a href="#">体坛下午茶</a></li>
        <li><a href="#">2017国际冠军杯</a></li>
    </ul>
</div>