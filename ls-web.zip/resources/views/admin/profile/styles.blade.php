<!-- Styles -->
    @section('styles')
    <!-- Css files -->
        <link href="{{ URL::asset('admin/css/bootstrap.min.css') }}" rel="stylesheet">     
        <link href="{{ URL::asset('admin/css/jquery.mmenu.css') }}" rel="stylesheet">      
        <link href="{{ URL::asset('admin/css/font-awesome.min.css') }}" rel="stylesheet">
        <link href="{{ URL::asset('admin/css/climacons-font.css') }}" rel="stylesheet">
        <link href="{{ URL::asset('admin/plugins/xcharts/css/xcharts.min.css') }}" rel=" stylesheet">      
        <link href="{{ URL::asset('admin/plugins/fullcalendar/css/fullcalendar.css') }}" rel="stylesheet">
        <link href="{{ URL::asset('admin/plugins/morris/css/morris.css') }}" rel="stylesheet">
        <link href="{{ URL::asset('admin/plugins/jquery-ui/css/jquery-ui-1.10.4.min.css') }}" rel="stylesheet">
        <link href="{{ URL::asset('admin/plugins/jvectormap/css/jquery-jvectormap-1.2.2.css') }}" rel="stylesheet">        
        <link href="{{ URL::asset('admin/css/style.min.css') }}" rel="stylesheet">
        <link href="{{ URL::asset('admin/css/add-ons.min.css') }}" rel="stylesheet">       

        <link href="{{ URL::asset('css/app.css') }}" rel="stylesheet">
    @show